# Agenda Outline

## Group Roles:
| Member | Role |
| ----------- | ----------- |
| braadams | TBD |
| cyrus-pdx | TBD | 
| jadiri28 | TBD |
| Sang-Buster | TBD | 

## Project Agenda:
- [ ] Establish group member roles.
- [ ] Establish timeline.
- [ ] Review updated project.


## Member Agenda:
### braadams:
- [ ] a.
- [ ] b.
- [ ] c.

##### Files Currently Editing
Agenda/Role
: Example.txt

### cyrus-pdx:
- [ ] a.
- [ ] b.
- [ ] c.

##### Files Currently Editing
Agenda/Role
: Example.txt

### jadiri28:
- [ ] a.
- [ ] b.
- [ ] c.

##### Files Currently Editing
Agenda/Role
: Example.txt

### Sang-Buster:
- [ ] a.
- [ ] b.
- [ ] c.

##### Files Currently Editing
Agenda/Role
: Example.txt
